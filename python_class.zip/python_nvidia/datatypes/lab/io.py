"""Lab:

Ask the user for their name.
Ask the user for their favorite color.
Fail politely if the user puts a ":" character in the name or color.
Write the name:color to the file "echo_out.txt".
Use a try/except and watch for IOError.
Before exiting, echo back all of the contents of the file, splitting
on the colon and formatting the name in a left aligned fixed width field of 20.
Run this multiple times to make sure it is working as expected.
"""

name = input('What is your name?\n')
color = input('What is your favorite color?\n')

with open('echo_out.txt', 'a') as f:
    pass
