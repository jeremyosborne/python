import numpy as np
import matplotlib.pyplot as plt
import pandas as pd


# Create a dataframe
dates = pd.date_range('20130101', periods=6)
df = pd.DataFrame(np.random.randn(6, 4), index=dates, columns=list('ABCD'))
print(df)

# Operate on
print(df.head())
print(df.tail(3))

print(df.columns)
print(df.values)

print(df.mean())

print(df.apply(np.cumsum))
print(df.apply(lambda x: x.max() - x.min()))

# Plot
# plt.figure()
plot = df.cumsum().plot()
plt.legend(loc='best')
plt.show()
