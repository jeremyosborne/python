"""
Add function implementations down below that make the tests pass.

>>> div(4, 2)
2
>>> div(4, 2, 2)
1
>>> div(4, 0)
Traceback (most recent call last):
...
ValueError: div can not take zeros!

"""


def div(*args):
    pass


if __name__ == "__main__":
    import doctest
    failures, tests = doctest.testmod()
    if not failures:
        print("All tests passed.")
