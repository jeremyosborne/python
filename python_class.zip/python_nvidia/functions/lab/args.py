""" Lab for working with function signatures.

    import sys for using sys.argv.
    import os for using os.path.join.
    Refer to the docs for how to use os.path.join.

    Write a commandline script that accepts n number of strings.
    Not including the execution script in sys.argv, combine all of the
    commandline options into a single path using os.path.join.
    print the path out to the screen.
    Your code must allow for a variable number of options/pathparts.
    (The path does not have to be valid.)
    If the user does not pass in any options, print a usage message.

    usage: python args.py some file name
"""

import sys
import os


def test(a, b, c):
    print("a + b + c =", a + b + c)


def pather(*parts):
    # type(parts) == tuple
    os.ipath.join(*parts)


if len(sys.argv) <= 1:
    print("you are using this wrong")
else:
    path_parts = sys.argv[1:]
    print(os.path.join(*path_parts))

    a = [1, 2, 3]
    test(*a)

    d = {'a': 2, 'b': 4, 'c': 6}
    test(**d)

    test(a=3, c=9, b=6)
