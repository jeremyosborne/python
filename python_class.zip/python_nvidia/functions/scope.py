""" Python expresses functional and modular scope for variables.
"""


# Global to the module, not global in the builtin sense.
x = 5

max = lambda x: x


def f1():
    """If not local, reference global.
    """
    return x


def f2():
    """Local references global.
    """
    global x
    x = 3
    return x


def f3(x=None):
    x = x or []

    def g():
        x.append(2)
        return x
        # return x + 2
    return g


def f4(x=None):
    x = x or []
    x.append(2)
    return x


d = f3()
print(d())
print(d())
print(d())

# Should print 5.
# print(f1())
# Should print 3.
# print(f2())
# Should print 3.
# print(x)

# When done, open the python interpreter and import this module.
# Note the output when importing.
# Note that our "global" x is only available via reference of scope.x.
