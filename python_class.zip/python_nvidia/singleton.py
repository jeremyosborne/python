class _elephant():
    def __init__(self, name='Dumbo'):
        self.name = name


class Elephant():
    inst = None

    def __new__(cls):
        if Elephant.inst:
            return Elephant.inst
        else:
            inst = _elephant()
            Elephant.inst = inst
            return inst


elephant = Elephant()


# def elephant(*args, **kwargs):
#     global inst
#     if inst:
#         return inst
#     else:
#         inst = _elephant(*args, **kwargs)
#         return inst


e = Elephant()
e2 = Elephant()
print(id(e) == id(e2))
