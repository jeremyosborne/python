# First install pip (google for instructions)
# Then to C:> pip install futures

# For more on futures, see
# http://pythonhosted.org/futures/

from concurrent.futures import *
from time import sleep


def doSomethingSlow(x):
    print("SomethingSlow-Starting")
    print(x)
    sleep(5)
    print("SomethingSlow-Done")
    return "A great result"


def itsDone(future):
    print("It's Done")
    print(repr(args))
    print("Result:" + str(future.result()))


print("Starting Main")
threadPool = ThreadPoolExecutor(5)
future = threadPool.submit(doSomethingSlow, "Hi")
future.add_done_callback(itsDone)
print("Finished Main")
