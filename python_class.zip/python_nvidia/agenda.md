
# Day 1

* Welcome, High level overview, agenda, intros, etc.
    * Python similarities and differences to other languages
    * Where and what for is python popular
    * Python 3 vs python 2
    * Discuss the Pythonic way, PEP 8, and knowing when to break the rules.
    * (While discussing the above, give people a chance to arrive and set up dev environment.)
    * a couple of gotchas in Python (just for fun, because nothing is perfect)
        * import this
        * import antigravity
        * from __future__ import braces
* Python for programmers (code-a-long plus comparisons to other languages while doing things)
    * built in data types
        * primitives: strings, int, float, complex, boolean, None, bytes
        * dicts, lists, tuples, sets, and files and their Python idiomatic uses
    * variables and flow of control in Python (with and for and iterators)
        * with, for, try/raise/except
    * modules, packages, and importing
        * how to find and install modules (pypi, pip)
    * classes and OO (and duck typing)
        * to thine own `self` be true
        * bound vs. unbound functions
        * what conveniences do classes give in Python vs. other data structures?

# Day 2

* Useful tools for doing more with less lines of code
    * Regular Expressions
    * Functional programming with the batteries included
        * aka. the times everyone agrees it is okay to use lambdas
        * list comprehensions
        * generators
        * iterators / iterables
    * decorators, you may not write many from scratch, but you will use them
* Common Libraries and Modules that make life easier
    * open, os and os.path, and io
    * scripting with subprocess and argparse

# Day 3

* threading vs. multiprocessing and why you will probably want multiprocessing
* Revisit pip and PyPI
* pytest (and nose) for making sure things work
* Numpy, Scipy
* Pandas Dataframes
* Matplotlib
