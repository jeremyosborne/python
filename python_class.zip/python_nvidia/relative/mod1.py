from sub.mod2 import x2, x3

x = 42

print(x, x2, x3)
