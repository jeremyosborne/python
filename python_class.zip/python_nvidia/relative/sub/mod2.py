from .more.mod3 import x3

x2 = 42
