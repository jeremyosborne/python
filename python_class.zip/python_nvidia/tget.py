#!/usr/bin/env python
"""
tget - read text from a particular url

Usage:
  tget <url>
"""

from bs4 import BeautifulSoup
import docopt
import requests
import sys

if __name__ == "__main__":
    arguments = docopt.docopt(__doc__)
    try:
        res = requests.get(arguments["<url>"])
    except Exception as err:
        print('sorry, could not retrieve:', arguments["<url>"])
        sys.exit(1)
    parser = BeautifulSoup(res.text, 'html.parser')
    print(parser.get_text())
