'''Decorators lab.

Make the following doctests pass. data is JSON.

>>> data = '{"username": "oscar", "password": "trashcan", "account": 1234, "amount": 12.03}'
>>> deposit(data)
'OK'
>>> data = '{"username": "oscar", "password": "trash", "account": 1234, "amount": 14.98}'
>>> deposit(data)
'Invalid Password'
>>> data = '{"username": "oscar", "password": "trashcan", "account": 1234, "amount": 4.12}'
>>> withdraw(data)
'OK'
>>> data = '{"username": "oscar", "password": "trashcan", "account": 1235, "amount": 2.54}'
>>> withdraw(data)
'Invalid Account'
>>> data = '{"username": "oscar", "password": "trashcan", "account": 1234}'
>>> balance(data)
'7.91'
>>> data = '{"username": "oscar", "password": "trashcan"}'
>>> balance(data)
'No Account Number Provided'
'''

import json  # json.loads()

accounts = {
    "oscar": {
        "password": "trashcan",
        "account": "1234",
        "amount": 0
    }
}


def password_check(f):
    def p(data):
        if data["password"] == accounts[data["username"]]["password"]:
            return f(data)
        else:
            return 'Invalid Password'
    return p


def account_check(f):
    def a(data):
        if data["account"] == accounts[data["username"]]["account"]:
            return f(data)
        else:
            return 'Invalid Account'
    return a


def json_parser(f):
    def g(data):
        return f(json.loads(data))
    return g


@json_parser
@password_check
@account_check
def deposit(data):
    accounts[data['username']]["amount"] += data['amount']
    return 'OK'


@json_parser
@password_check
@account_check
def balance(data):
    return accounts[data['username']]["amount"]


@json_parser
@password_check
@account_check
def withdraw(data):
    accounts[data['username']]["amount"] -= data['amount']
    return 'OK'


if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=True)
