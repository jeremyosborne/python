'''
Use sorted and key functions!

>>> numbers = [0, 2, 3, 5, -1, -4]
>>> words = "Beautiful is better than ugly".split(" ")

>>> sort_abs(numbers)
[0, -1, 2, 3, -4, 5]
>>> sort_last_letter(words)
['Beautiful', 'than', 'better', 'is', 'ugly']

'''


def sort_abs(numbers):
    return list(sorted(numbers, key=lambda n: abs(n)))


def sort_last_letter(words):
    return list(sorted(words, key=lambda w: w[-1]))


if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=True)
