'''
Use sorted and key functions!

>>> numbers = [0, 2, 3, 5, -1, -4]
>>> words = "Beautiful is better than ugly".split(" ")

>>> sort_abs(numbers)
[0, -1, 2, 3, -4, 5]
>>> sort_last_letter(words)
['Beautiful', 'than', 'better', 'is', 'ugly']

'''


def sort_abs(numbers):
    pass


def sort_last_letter(words):
    pass


if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=True)
