'''
Use the builtin filter function to complete the following:

>>> numbers = [0, 2, 3, 5, -1, -4]

>>> positive(numbers)
[2, 3, 5]
>>> non_zero(numbers)  # use filter, but don't write any other functions
[2, 3, 5, -1, -4]

'''


def positive(numbers):
    return list(filter(lambda x: x > 0, numbers))


def non_zero(numbers):
    return list(filter(None, numbers))


if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=True)
