'''
Use the builtin "map" function to complete the following:

>>> numbers = [0, 2, 3, 5, -1, -4]
>>> words = "Beautiful is better than ugly".split(" ")

>>> double_numbers(numbers)
[0, 4, 6, 10, -2, -8]
>>> lower_case(words)
['beautiful', 'is', 'better', 'than', 'ugly']
'''


def double_numbers(numbers):
    return list(map(lambda x: x * 2, numbers))


def lower_case(words):
    return list(map(lambda w: w.lower(), words))


if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=True)
