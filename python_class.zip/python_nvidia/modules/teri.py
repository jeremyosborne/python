import mod3.bob

print("bob's x value is:", mod3.bob.x)
