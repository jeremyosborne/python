print("mod3: init, nothing else happens here")
