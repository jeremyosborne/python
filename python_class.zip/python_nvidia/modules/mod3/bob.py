from 'mod3.teri'

print("hi i'm bob")

y = 42
