print('hi i\'m teri also.')
