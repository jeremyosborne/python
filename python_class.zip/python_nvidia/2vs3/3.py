# will error
# print 'hello world'

print('hello world')

# Get rid of line ending in Python 3 print
print('hello', 'world', end='')

print('\nDivision:', 1 / 2)


class Oldie:
    pass


class Newie(object):
    pass


print('Only new style: %s %s' % (type(Oldie), type(Newie)))

s = 'unicode string'
print(s, type(s))

s = u'unicode string, backwards compatible'
print(s, type(s))
