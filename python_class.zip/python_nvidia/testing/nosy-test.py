#
# Testing with nose
# see: http://nose.readthedocs.io/
#
# run with: nosetests

from nose import with_setup

x = 0


def helpers():
    old_x = x

    def setup_func():
        global x
        x = 5

    def teardown_func():
        global x
        x = old_x

    return (setup_func, teardown_func)


@with_setup(*helpers())
def test():
    assert x == 5
