def json_parser(f):
    def g(data):
        return f(json.loads(data))
    return g


def tester(d):
    assert type(d) == dict


json_parser(tester)("{}")
