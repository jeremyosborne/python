import re
import requests
from collections import Counter

res = requests.get("http://docs.python-requests.org/en/master/")
tags = re.findall(r"<(\w+)[\s>]", res.text, re.I)
print(tags)
counts = Counter(tags)
print(counts.most_common(5))

# Singleton pattern?


