"""
>>> filename = r"log.txt"
>>> print_lines(filename)
localhost - - [09/Jul/2010:13:08:34 -0700] "POST /printers/HP_LaserJet_P2015_Series HTTP/1.1" 200 949462 Send-Document successful-ok
localhost - - [09/Jul/2010:13:08:34 -0700] "POST / HTTP/1.1" 200 313 Set-Job-Attributes successful-ok
localhost - - [09/Jul/2010:13:09:15 -0700] "POST /printers/HP_LaserJet_P2015_Series HTTP/1.1" 200 1669 Create-Job successful-ok
localhost - - [09/Jul/2010:13:09:15 -0700] "POST /printers/HP_LaserJet_P2015_Series HTTP/1.1" 200 79979 Send-Document successful-ok
localhost - - [09/Jul/2010:13:09:16 -0700] "POST / HTTP/1.1" 200 313 Set-Job-Attributes successful-ok
localhost - - [09/Jul/2010:13:09:54 -0700] "POST /printers/HP_LaserJet_P2015_Series HTTP/1.1" 200 1496 Create-Job successful-ok
localhost - - [09/Jul/2010:13:09:54 -0700] "POST /printers/HP_LaserJet_P2015_Series HTTP/1.1" 200 73339 Send-Document successful-ok
localhost - - [09/Jul/2010:13:09:54 -0700] "POST / HTTP/1.1" 200 313 Set-Job-Attributes successful-ok
localhost - - [11/Jul/2010:22:05:31 -0700] "POST /printers/HP_LaserJet_P2015_Series HTTP/1.1" 200 1453 Create-Job successful-ok

>>> grep(filename, 'HTTP')
localhost - - [09/Jul/2010:13:08:34 -0700] "POST /printers/HP_LaserJet_P2015_Series HTTP/1.1" 200 949462 Send-Document successful-ok
localhost - - [09/Jul/2010:13:08:34 -0700] "POST / HTTP/1.1" 200 313 Set-Job-Attributes successful-ok
localhost - - [09/Jul/2010:13:09:15 -0700] "POST /printers/HP_LaserJet_P2015_Series HTTP/1.1" 200 1669 Create-Job successful-ok
localhost - - [09/Jul/2010:13:09:15 -0700] "POST /printers/HP_LaserJet_P2015_Series HTTP/1.1" 200 79979 Send-Document successful-ok
localhost - - [09/Jul/2010:13:09:16 -0700] "POST / HTTP/1.1" 200 313 Set-Job-Attributes successful-ok
localhost - - [09/Jul/2010:13:09:54 -0700] "POST /printers/HP_LaserJet_P2015_Series HTTP/1.1" 200 1496 Create-Job successful-ok
localhost - - [09/Jul/2010:13:09:54 -0700] "POST /printers/HP_LaserJet_P2015_Series HTTP/1.1" 200 73339 Send-Document successful-ok
localhost - - [09/Jul/2010:13:09:54 -0700] "POST / HTTP/1.1" 200 313 Set-Job-Attributes successful-ok
localhost - - [11/Jul/2010:22:05:31 -0700] "POST /printers/HP_LaserJet_P2015_Series HTTP/1.1" 200 1453 Create-Job successful-ok

>>> grep(filename, '09/Jul/2010:13:08:34')
localhost - - [09/Jul/2010:13:08:34 -0700] "POST /printers/HP_LaserJet_P2015_Series HTTP/1.1" 200 949462 Send-Document successful-ok
localhost - - [09/Jul/2010:13:08:34 -0700] "POST / HTTP/1.1" 200 313 Set-Job-Attributes successful-ok

>>> grep(filename, r'200 \d{5,6} ')
localhost - - [09/Jul/2010:13:08:34 -0700] "POST /printers/HP_LaserJet_P2015_Series HTTP/1.1" 200 949462 Send-Document successful-ok
localhost - - [09/Jul/2010:13:09:15 -0700] "POST /printers/HP_LaserJet_P2015_Series HTTP/1.1" 200 79979 Send-Document successful-ok
localhost - - [09/Jul/2010:13:09:54 -0700] "POST /printers/HP_LaserJet_P2015_Series HTTP/1.1" 200 73339 Send-Document successful-ok

"""

import re


def print_lines(filename):
    with open(filename, 'r') as f:
        for line in f:
            print(line.rstrip())


def grep(filename, pattern):
    with open(filename, 'r') as f:
        for line in f:
            if re.search(pattern, line):
                print(line.rstrip())


if __name__ == "__main__":
    import doctest
    failures, tests = doctest.testmod()
    if not failures:
        print("All tests passed.")
