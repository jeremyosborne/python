from __future__ import print_function
from __future__ import division

import json

class Animal():
    def __init__(self, name='Bob'):
        self.name = name

    def speak(self):
        return "Hello, I'm an animal"

    def __eq__(self, right):
        if isinstance(right, Animal):
            return True
        else:
            return False

    @property
    def full_name(self):
        return "{} the Animal".format(self.name)

    def echo(*args, **kwargs):
        if len(args):
            pass
        elif len(kwargs):
            pass


class JsonMixin():
    def to_json(self):
        return json.dumps({'name': self.name})


class Cat(Animal, JsonMixin):
    def __init__(self):
        super().__init__('george')


if __name__ == "__main__":
    a = Animal()
    print(a.name)
    a.hair = 'blue'
    print(a.hair)
    print(a.speak())
    bob = Animal()
    print(a == bob)
    print(bob.full_name)
    c = Cat()
    print(c.full_name)
