""" Our base Die class.
"""

from random import randint


class Die():
    def __init__(self, faces=6):
        self.faces = 6

    def roll(self):
        return randint(1, self.faces)

    def __add__(self, right):
        return self.roll() + right.roll()
