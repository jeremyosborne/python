""" Die subclasses.
"""
