"""
Add function implementations down below that make the tests pass.

>>> column_vals(data, 0)
[6, 20, 38]
>>> column_vals(data, -1)
[24, 28, 31, 33]
>>> add_row(range(5))
>>> data[-1]
[0, 1, 2, 3, 4]
>>> lst = [1, 2, 3]
>>> append_sum(lst)
[1, 2, 3, 6]
>>> append_sum()
[0]
>>> append_sum()
[0]

"""
x = 1
data = [[38, 20, 0, 34, 33],
        [20, 36, 18, 14, 24],
        [6, 13, 26, 29, 28],
        [6, 35, 25, 32, 31]]


def column_vals(data, col):
    pass


def add_row(row):
    pass


def append_sum(items=None):
    pass


if __name__ == "__main__":
    import doctest
    failures, tests = doctest.testmod()
    if not failures:
        print("All tests passed.")
