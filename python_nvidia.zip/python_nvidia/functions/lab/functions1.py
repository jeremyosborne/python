"""
Add function implementations down below that make the tests pass.

>>> add_2(4, 5)
9
>>> add_2(4) # use a default value
4
>>> add_many([1, 2, 3])
6
>>> choose_longer("abc", "qwer")
'qwer'
>>> choose_longer([1, 2, 3], (1, 2))
[1, 2, 3]
>>> choose_longer("a", "word", "can", "have", "a", "length") # looks like a case for *args!
'length'

"""


def add_2():
    pass


def add_many():
    pass


def choose_longer():
    pass


if __name__ == "__main__":
    import doctest
    failures, tests = doctest.testmod()
    if not failures:
        print("All tests passed.")
