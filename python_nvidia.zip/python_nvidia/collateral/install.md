# Python class setup

Greetings! Thank you for signing up and attending the upcoming Python class. Please make sure to: 

* bring a laptop and battery charger to the class. 
* make sure your laptop is setup with the prerequisites for the class.

You may already have `Python3` and `pip` installed by your company. We will be using Python 3.6 for the examples in the class. If you do not already have Python 3 installed, the following will get you set up. Please come to class prepared with a minimum of the following:

* Python 3 and pip
* A virtual environment with the listed Third Party Libraries installed
* An editor of your choice (I am not picky about editors. Your editor should make you happy and be Python friendly. Even Vim is Python friendly if you configure it.)

## Prereq: Python3 and Pip

```bash
# Mac
brew install python3
# Windows
https://docs.python.org/3/using/windows.html
# or if you can use Chocolatey:
https://www.digitalocean.com/community/tutorials/how-to-install-python-3-and-set-up-a-local-programming-environment-on-windows-10
# *NIX
# check for your distro, likely `yum install python3` or `apt-get install python3`

# Make sure version is 3.6 and that both work
pip3 --version
python3 --version
```

## Prereq: Third Party Libraries

We will use `pip3` to install third party libraries. But instead of installing them globally, we want to install them in a virtual environment.

```bash
# First make a VirtualEnv, safe place to install per-project packages
python3 -m venv python_class
cd python_class

# *NIX
source bin/activate
# Windows
\path\to\env\Scripts\activate

# Once activated, Install dependencies within our environment
# Being in the virtualenv aliases `pip` to `pip3` and `python` to `python3`
pip install numpy scipy matplotlib ipython jupyter pandas pandas-datareader sympy nose pycodestyle

# When done
deactivate
```

## Prereq: Editor

The editor is your choice. We will be focusing on samples. There are many good python editors out there, I personally use Atom and will be using it during the class. Most examples we will execute from command line. No example will ever rely on a specific editor to run.

Atom editor from: https://atom.io

Install useful dependencies for the editor:

```bash
apm install autocomplete-python language-python script linter linter-pycodestyle
```
