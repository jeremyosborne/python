# Run the ls -lh command and count the number of lines of
# output from stdout.
# Display the number of lines from ls -lh.
# Count and display the number of directories.
