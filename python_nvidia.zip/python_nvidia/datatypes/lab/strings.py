""" Various string based mini labs.
"""

# Print out a checkerboard -- 8x8 grid with alternating light and dark
# squares -- and make use of the .format method on a string.

# Break a string into (assumed) word chunks and print the words in reverse
# order, one on each line. Use either a regex or the .split method.
