'''
Use the builtin filter function to complete the following:

>>> numbers = [0, 2, 3, 5, -1, -4]

>>> positive(numbers)
[2, 3, 5]
>>> non_zero(numbers)  # use filter, but don't write any other functions
[2, 3, 5, -1, -4]

'''


def positive(numbers):
    pass


def non_zero(numbers):
    pass


if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=True)
