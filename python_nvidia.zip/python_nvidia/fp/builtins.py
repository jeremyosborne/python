""" Python provides quite a few utilities, as builtins and as part of the
    standard library, to work with sequences.
"""

import string
import collections
from functools import reduce

# Make a list of all of the ascii_letters and numbers.
l = [i for i in range(10)]
mixed_list = list(string.ascii_letters) + [i for i in range(10)]

# Test if all values are truthy.
print(all(mixed_list))

# Are any values truthy?.
print(any(mixed_list))

# Can we call the identifier (as a function)?
print(isinstance(mixed_list, collections.Callable))

# Construct a new list with reference to each element that passes our
# test.
# Functions can be passed into other functions in Python without fanfare.


def oddnumbers(x):
    return type(x) == int and x % 2 == 1


l2 = list(filter(oddnumbers, l))
print(l2)

# People seem to hate on lambdas. I don't have a problem with them.
# The following is equivalent to the above, as a single line expression
# using a Python lambda (i.e. anonymous function).
l2 = [x for x in l if type(x) == int and x % 2 == 1]
print(l2)

# Don't do the following on a mixed list.
print(max(l))
# instead, Maximum of only the numbers in our list.
print(max([x for x in mixed_list if type(x) == int]))

# Minimum value of a sequence.
print(max([x for x in l if type(x) == int]))

# Apply function to each element in sequence, return new list with results.


def identifier(x):
    if type(x) == str:
        # Be careful of the above going forward. Python 3 works in unicode.
        return "letter"
    elif type(x) == int:
        return "number"
    else:
        return "wtf?"


print(list(map(identifier, mixed_list)))


# Return sum of a sequence (mainly for numbers).
# Using a generator to just get the numbers out.
print(sum(x if type(x) == int else 0 for x in l))


# Like sum, more useful on complex sequences.


def reducer(subtotal, nextitem):
    if type(subtotal) == str:
        subtotal = 0
    if type(nextitem) == str:
        nextitem = 0
    return subtotal + nextitem


print(reduce(reducer, l))


# Sort a sequence, returning a new sequence.
# (Arbitrary for heterogeneous list.)
print(sorted(l))
# Descending order.
print(sorted(l, reverse=True))
# Treat upper and lowercase letters as equals.


def sorter(x):
    if type(x) == str:
        return ord(x.lower())
    return x


print(sorted(mixed_list, key=sorter, reverse=True))


# There are multiple ways of sorting a dict by value. This is one.
d = {"dog": 40, "pig": 54, "horse": 5}
sorted(list(d.items()), key=lambda x: x[1], reverse=True)


# Group two+ sequences together into a list of tuples.
print(list(zip(list(d.keys()), list(d.values()))))
# This of course is much what .items() does.
print(list(d.items()))
