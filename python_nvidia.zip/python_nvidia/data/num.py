# NumPy‘s array type augments the Python language with an efficient data
# structure useful for numerical work, e.g., manipulating matrices. NumPy also
# provides basic numerical routines, such as tools for finding eigenvectors.

import numpy as np

# Basic usage
a = np.arange(15).reshape(3, 5)
print(a)
print(a.shape)
print(a.ndim)
print(a.dtype.name)
print(a.itemsize)
print(a.size)
print(type(a))
b = np.array([6, 7, 8])
print(b)
print(type(b))

# Basic Operations
a = np.array([20, 30, 40, 50])
b = np.arange(4)
print(b)
c = a - b
print(c)
print(b**2)
print(10 * np.sin(a))
print(a < 35)

print(a.min())
print(a.max())
print(a.sum())
