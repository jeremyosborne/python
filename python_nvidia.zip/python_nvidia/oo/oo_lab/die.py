""" Our base Die class.
"""
