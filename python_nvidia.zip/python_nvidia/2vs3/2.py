# Achieve python 3 compatibility with
# from __future__ import print_function
# from __future__ import division

print 'hello world'

# this appears like it works by luck
print('hello world')

# What is this actually printing?
print('hello', 'world')

# Get rid of line endings.
print 'hello', 'world',

print '\nDivision:', 1 / 2


class Oldie:
    pass


class Newie(object):
    pass


print 'Old vs new style: %s %s' % (type(Oldie), type(Newie))

s = 'ascii string'
print s, type(s)

s = u'unicode string'
print s, type(s)
